#!/bin/bash

#This command goes to the previous latest directory.

export directoryStackCount=`cat /tmp/directoryStack.txt | wc -l`
if [ $directoryStackCount -eq 0 ]
then
    echo "No entry in directory stack"
    exit 0
else
    export previousPath=`tail -n 1 /tmp/directoryStack.txt`
    cd $previousPath
    if [ $? -eq 0 ]
    then
        `sed '$d' /tmp/directoryStack.txt > /tmp/directoryStack.txt` 
    else
        echo "command error"
    fi
fi
