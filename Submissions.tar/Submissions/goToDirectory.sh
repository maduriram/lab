#!/bin/bash

#This command changes directory to specified path or foider. 

export switchToDirectory=$1

cd $switchToDirectory
export presentDirectory=`pwd`
echo $presentDirectory/ >> /tmp/directoryStack.txt

